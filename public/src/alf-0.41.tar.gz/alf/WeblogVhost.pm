#########################################################
package AnyData::Format::WeblogVhost;
#########################################################
# AnyData driver for "Vhost Log Format" web log files
# Also supports combined and common log formats. 
# Copyright (c) 2007, Charlie <charlie@charlieharvey.com>
#########################################################

=head1 NAME

 AnyData::Format::WeblogVhost - tiedhash & DBI/SQL access to HTTPD Logs

=head1 SYNOPSIS

 use AnyData;
 my $weblog = adTie( 'Weblog', $filename );
 while (my $hit = each %$weblog) {
    print $hit->{remotehost},"\n" if $hit->{request} =~ /mypage.html/;
 }
 # ... other tied hash operations

 OR

 use DBI
 my $dbh = DBI->connect('dbi:AnyData:');
 $dbh->func('hits','Weblog','access_log','ad_catalog');
 my $hits = $dbh->selectall_arrayref( qq{
     SELECT remotehost FROM hits WHERE request LIKE '%mypage.html%'
 });
 # ... other DBI/SQL read operations

=head1 DESCRIPTION

This is a plug-in format parser for the AnyData and DBD::AnyData modules. You can gain read access to Vhost Log Format 
files web server log files (e.g. NCSA or Apache) either through tied hashes or arrays or through SQL database queries.

Fieldnames are taken from the W3 definitions found at, with the addition of client, referer and vhost fields

http://www.w3.org/Daemon/User/Config/Logging.html#common-logfile-format

 remotehost
 usernname
 authuser
 date
 request
 status
 bytes
 referer
 client
 vhost

This module does not currently support writing to weblog files.

Please refer to the documentation for AnyData.pm and DBD::AnyData.pm
for further details.

=head1 LICENCE

               Copyright (C)2007  Charlie Harvey

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version
 2 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be
 useful, but WITHOUT ANY WARRANTY; without even the implied
 warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 PURPOSE.  See the GNU General Public License for more
 details.

 You should have received a copy of the GNU General Public
 License along with this program; if not, write to the Free
 Software Foundation, Inc., 59 Temple Place - Suite 330,
 Boston, MA  02111-1307, USA.
 Also available on line: http://www.gnu.org/copyleft/gpl.html

=cut

use strict;
use AnyData::Format::Base;
use vars qw( @ISA $DEBUG $VERSION);
@AnyData::Format::WeblogVhost::ISA = qw( AnyData::Format::Base );
$DEBUG = 0;
$VERSION = '0.01';

my $vlog_re       = qr/^(\S*) (\S*) (\S*) (\S*) \[([^\]]*)\] "(.*?)" (\S*) (\S*)\s*(.*)$/;
my $norm_re       = qr/^(\S*) (\S*) (\S*) \[([^\]]*)\] "(.*?)" (\S*) (\S*)\s*(.*)$/;
my $ref_client_re = qr/^"(.*?)" "(.*?)".*$/;

sub new {
    my $class = shift;
    my $self = shift || {};
    $self->{col_names} =
        'vhost,remotehost,username,authuser,date,request,status,bytes,client,referer';
    $self->{record_sep} = "\n";
    $self->{key} = 'datestamp';
    $self->{keep_first_line} = 1;
    return bless $self, $class;
}

sub read_fields {
    my $self = shift;
    my $str  = shift || return undef;
    $str =~ s/^\s+//;
    $str =~ s/\s+$//;
    return undef unless $str;
    my @row;
    if($str =~ /VLOG=-$/) {
    	(@row) = $str =~ $vlog_re;
    }
    else {
    	(@row) = ('', $str =~ $norm_re);
    }
    return undef unless defined $row[0];
    my($referer,$client) = $row[8] =~ $ref_client_re; 
    $client  ||= '';
    $referer ||= '';
    ($row[8],$row[9])=($client,$referer);
    # $row[3] =~ s/\s*-\s*(\S*)$//; # hide GMT offset on datestamp
    return @row
}
1;
