#!/usr/bin/perl
use strict;
use warnings;

my $menu_tree = [
  _File => {
    item_type => '<Branch>',
    children  => [
      _Open => {
        item_type       => '<StockItem>',
	extra_data      => 'gtk-open',
	callback        => \&open_log,
	callback_action => 0,
	accelerator     => '<ctrl>O',
      },
      _Save => {
        item_type       => '<StockItem>',
	extra_data      => 'gtk-save',
        callback_action => 1,
	callback        => \&export_results,
	accelerator     => '<ctrl>S',
      },
      _Quit => {
	item_type       => '<StockItem>',
	extra_data      => 'gtk-quit',
	callback        => \&close,
	callback_action => 3,
	accelerator     => '<ctrl>Q',
      },
    ],
  },
# _Edit =>{
#   item_type=>'<Branch>',
#   children => [
#     Pr_eferences => {
#       item_type       => '<StockItem>',
#       extra_data      => 'gtk-preferences',
#       callback_action => 9,
#     },
#   ],
#  },
  For_mat => {
    item_type => '<Branch>',
    children  => [
      _Combined => {
        item_type       => '<RadioItem>',
        callback        => \&set_log_type,
        callback_action => 4,
        groupid         => 1,
      },
      _Vhost => {
        item_type       => '<RadioItem>',
        callback        => \&set_log_type,
        callback_action => 5,
        groupid         => 1,
      },
      _Common => {
        extra_data      => 1,
        item_type       => '<RadioItem>',
        callback        => \&set_log_type,
        callback_action => 6,
        groupid         => 1,
      },
    ],
  },
  _Help => {
    item_type => '<Branch>',
    children  => [
      _About => {
	item_type       => '<StockItem>',
	extra_data      => 'gtk-about',
        callback        => \&about,
        callback_action => 7,
      },
    ],
  },
];
